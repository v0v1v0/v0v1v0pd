// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"
using namespace Rcpp;
using namespace arma;

// via the depends attribute we tell Rcpp to create hooks for
// RcppArmadillo so that the build process will know what to do
//
// [[Rcpp::depends(RcppArmadillo)]]



// [[Rcpp::export]]
List doe_find_best_delta_cpp(int row_i,
                              int cand_i,
                              IntegerVector test_cand,
                              arma::mat st,
                              arma::mat blocks,
                              arma::mat xmat) {

  int best_pair = -1;
  double best_delta = -std::numeric_limits<double>::infinity();

  arma::rowvec b = blocks.row(row_i);
  arma::rowvec x_old = xmat.row(cand_i);
  arma::vec z_old = arma::join_vert(b.t(), x_old.t()); // column vector

  double p2 = as_scalar(z_old.t() * st * z_old);

  for (int j = 0; j < test_cand.size(); ++j) {
    int cand_j = test_cand[j];
    if (cand_j == cand_i) continue;

    arma::rowvec x_new = xmat.row(cand_j);
    arma::vec z_new = arma::join_vert(b.t(), x_new.t());

    double p1 = as_scalar(z_new.t() * st * z_new);
    double ct = as_scalar(z_new.t() * st * z_old);

    double delta = p1 - p2 + ct * ct - p1 * p2;

    if (std::isnan(delta) || std::isinf(delta)) continue;

    if (delta > best_delta) {
      best_delta = delta;
      best_pair = cand_j;
    }
  }

  return List::create(
    Named("best_pair") = best_pair,
    Named("best_delta") = best_delta
  );
}




/*
 * Sherman–Morrison rank-1 update:
 *  add = TRUE  :  S_new = S - (S u uᵀ S) / (1 + uᵀ S u)
 *  add = FALSE :  S_new = S + (S u uᵀ S) / (1 - uᵀ S u)
 *
 * This mirrors your R function:
 * rank1_update(vec, S, add = TRUE)
 */
// [[Rcpp::export]]
arma::mat rank1_update_cpp(const arma::vec& v,
                           const arma::mat& S,
                           const bool add = true,
                           const double eps = 1e-12)
{
  arma::vec Su = S * v;
  double vSv  = arma::as_scalar(v.t() * Su);
  double den  = add ? (1.0 + vSv) : (1.0 - vSv);

  if (std::abs(den) < eps) {
    Rcpp::warning("rank1_update_cpp: denominator near zero; skipping update.");
    return S;
  }

  arma::mat num = Su * Su.t();
  return add ? arma::mat(S - num / den) : arma::mat(S + num / den);  // ✅ fixed
}



inline arma::vec make_z(const arma::rowvec& b, const arma::rowvec& x) {
  return arma::join_vert(b.t(), x.t());
}



// [[Rcpp::export]]
arma::mat updated_S_cpp(const int row_i,
                        const int cand_i,
                        const int cand_j,
                        const arma::mat& S,
                        const arma::mat& blocks,
                        const arma::mat& xmat,
                        const double eps = 1e-12)
{
  if (row_i  < 0 || row_i  >= static_cast<int>(blocks.n_rows))
    stop("row_i out of bounds");
  if (cand_i < 0 || cand_i >= static_cast<int>(xmat.n_rows))
    stop("cand_i out of bounds");
  if (cand_j < 0 || cand_j >= static_cast<int>(xmat.n_rows))
    stop("cand_j out of bounds");

  arma::rowvec b      = blocks.row(row_i);
  arma::rowvec x_old  = xmat.row(cand_i);
  arma::rowvec x_new  = xmat.row(cand_j);

  arma::vec z_old = make_z(b, x_old);
  arma::vec z_new = make_z(b, x_new);

  arma::mat S1 = rank1_update_cpp(z_old, S, /*add=*/false, eps); // delete
  return rank1_update_cpp(z_new, S1, /*add=*/true, eps);         // add
}


// [[Rcpp::export]]
double logdet_cpp(const arma::mat& S, const double eps = 1e-12) {
  double sign = 0.0;
  double logdet = 0.0;
  arma::log_det(logdet, sign, S);

  if (!std::isfinite(logdet) || sign <= 0.0) {
    Rcpp::warning("logdet_cpp: matrix is singular or not positive-definite.");
    return NA_REAL;
  }

  return logdet;
}

// [[Rcpp::export]]
double row_swap_logdet_cpp(const int pi,
                            const int pj,
                            const arma::rowvec& temp_i,
                            const arma::rowvec& temp_j,
                            const arma::mat& S,
                            const arma::mat& blocks,
                            const arma::mat& xmat,
                            const double eps = 1e-12) {
  if (pi < 0 || pi >= static_cast<int>(blocks.n_rows)) stop("pi out of bounds");
  if (pj < 0 || pj >= static_cast<int>(blocks.n_rows)) stop("pj out of bounds");

  arma::rowvec bi = blocks.row(pi);
  arma::rowvec bj = blocks.row(pj);

  arma::vec zi_old = make_z(bi, temp_i);
  arma::vec zi_new = make_z(bi, temp_j);
  arma::vec zj_old = make_z(bj, temp_j);
  arma::vec zj_new = make_z(bj, temp_i);

  arma::mat S2 = rank1_update_cpp(zi_old, S, false, eps);
  S2           = rank1_update_cpp(zi_new, S2, true,  eps);
  S2           = rank1_update_cpp(zj_old, S2, false, eps);
  S2           = rank1_update_cpp(zj_new, S2, true,  eps);

  return logdet_cpp(S2, eps);
}
