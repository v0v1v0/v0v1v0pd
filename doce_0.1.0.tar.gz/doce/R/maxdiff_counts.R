#' Compute Pairwise Co-occurrence Counts in a MaxDiff Design
#'
#' Calculates how often each pair of items appears together across all tasks and versions
#' in a MaxDiff design. This is useful for evaluating design balance and checking for over- or under-represented item pairs.
#'
#' @param design A data frame in wide format, such as the output from `generate_design()`, with columns `version`, `task`, and item columns (e.g., `Item1`, `Item2`, ...).
#'
#' @return A square matrix where entry \code{[i, j]} indicates the number of times item \code{i} and item \code{j} appeared together in the same task.
#'
#' @examples
#' \dontrun{
#' design <- generate_design()
#' pairwise_matrix <- pairwise_counts(design)
#'
#' # Visualize the co-occurrence matrix
#' image(pairwise_matrix)
#' }
#'
#' @export
maxdiff_pairwise_counts <- function(design){
  consideration_set <- as.matrix(design[,-(1:2)])
  xmat_consideration_set <- matrix(0L, nrow = nrow(consideration_set), ncol = max(consideration_set))
  for(row_i in 1:nrow(consideration_set)){
    xmat_consideration_set[row_i, consideration_set[row_i,]] <- 1L
  }
  xmat_consideration_set <- as.matrix(xmat_consideration_set)
  counts <- t(xmat_consideration_set) %*% xmat_consideration_set
  return(counts)
}


#' Compute Item Counts by Version, Task, and Position
#'
#' Aggregates a MaxDiff design to compute how frequently each item appears:
#' - per version (across tasks),
#' - per task (across versions), and
#' - in each item position within a task (e.g., Item1, Item2, ...).
#'
#' This is useful for assessing balance in experimental design, such as whether certain items
#' are over- or under-represented by version, task, or screen position.
#'
#' @param design A data frame in wide format with columns `version`, `task`, and one or more item columns (e.g., `Item1`, `Item2`, ...), typically from `generate_design()`.
#'
#' @return A named list of three data frames:
#' \describe{
#'   \item{\code{$version}}{Item frequency per version (rows = versions, columns = items)}
#'   \item{\code{$task}}{Item frequency per task (rows = tasks, columns = items)}
#'   \item{\code{$position}}{Item frequency by screen position (rows = positions, columns = items)}
#' }
#'
#' @examples
#' \dontrun{
#' design <- generate_design()
#' counts <- maxdiff_position_counts(design)
#' counts$version
#' counts$task
#' counts$position
#' }
#'
#' @export
maxdiff_position_counts <- function(design){
  long_design <- tidyr::pivot_longer(design,
                                     cols=-(1:2),
                                     names_to = "position",
                                     values_to ="item")
  counts <- list()
  counts$version <- long_design |> dplyr::group_by(version,item) |>
    dplyr::count() |> tidyr::pivot_wider(names_from ="item",
                                         names_prefix ="Item",
                                         values_from ="n")

  counts$task <- long_design |> dplyr::group_by(task,item) |>
    dplyr::count() |> tidyr::pivot_wider(names_from ="item",
                                         names_prefix ="Item",
                                         values_from ="n")

  counts$position <- long_design |> dplyr::group_by(position,item) |>
    dplyr::count() |> tidyr::pivot_wider(names_from ="item",
                                         names_prefix ="Item",
                                         values_from ="n")


  return(counts)
}

#' Summarize MaxDiff Design with Pairwise and Positional Counts
#'
#' Returns a comprehensive set of frequency tables summarizing a MaxDiff design. It includes:
#' - Item frequency by version, task, and position
#' - Pairwise co-occurrence of items within tasks
#'
#' This function is useful for debugging, auditing, and validating the statistical balance of a design.
#'
#' @param design A data frame in wide format, such as output from `maxdiff_design()`, with columns `version`, `task`, and one or more item columns (e.g., `Item1`, `Item2`, ...).
#'
#' @return A named list with:
#' \describe{
#'   \item{\code{$version}}{Item frequency per version (from `maxdiff_position_counts()`)}
#'   \item{\code{$task}}{Item frequency per task}
#'   \item{\code{$position}}{Item frequency per position}
#'   \item{\code{$pairwise}}{Matrix of item pairwise co-occurrence counts (from `maxdiff_pairwise_counts()`)}
#' }
#'
#' @examples
#' \dontrun{
#' design <- maxdiff_design()
#' counts <- maxdiff_counts(design)
#' str(counts)
#' }
#'
#' @export
maxdiff_counts <- function(design){
  counts <- maxdiff_position_counts(design)
  counts$pairwise <- maxdiff_pairwise_counts(design)
  return(counts)
}
