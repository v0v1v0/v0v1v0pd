
util_random_int_less_than_or_equal <- function(n, vec) {
  return(floor(runif(n, min = 1, max = vec + 1)))
}
get_consideration_indices <- function(cand_i, self, search_proportion, p_range = NULL) {
  if (is.null(p_range)) {
    p_range <- 1:(self$concepts - 1)
  }
  current_items <- unlist(self$consideration_set[cand_i, ])
  p <- p_range[util_random_int_less_than_or_equal(1, length(p_range))]
  p_name <- paste0("p", p)
  p_ref <- self$master_item_cache$references[[p]]$concepts
  p_name_groups <- apply(p_ref, 1, function(x) paste(current_items[x], collapse = "|"))

  consideration_indices <- unique(unlist(self$master_item_cache[[p_name]][p_name_groups]))

  if (search_proportion < .99) {
    ci_len <- length(consideration_indices)
    subset_to <- sample(seq_len(ci_len), floor(ci_len * search_proportion))
    consideration_indices <- consideration_indices[subset_to]
  }

  return(consideration_indices)
}

create_master_cache <- function(self) {
  mil <- 1:(self$concepts - 1)
  master_item_cache <- list(
    references = vector("list", length(mil)),
    "p1" = vector("list", self$num_of_items)
  )

  for (c_i in mil) {
    item_index_concepts <- t(combn(self$concepts, c_i)) |> as.matrix()
    item_index_items <- t(combn(self$num_of_items, c_i)) |> as.matrix()
    master_item_cache$references[[c_i]] <- list(concepts = item_index_concepts, items = item_index_items)
  }

  for (item_i in seq_len(self$num_of_items)) {
    master_item_cache$p1[[paste0(item_i)]] <- as.integer(which(self$xmat[, item_i] %in% 1))
  }
  for (c_i in mil[-1]) {
    ref_list <- master_item_cache$references[[c_i]]$items
    ref_cache <- master_item_cache[[paste0("p", c_i - 1)]]

    last_col <- ncol(ref_list)
    first_col <- 1L

    temp_list <- vector("list", nrow(ref_list))
    names(temp_list) <- apply(ref_list, 1, function(x) paste(x, collapse = "|"))

    for (row_i in seq_len(nrow(ref_list))) {
      all_but_last <- paste0(unlist(ref_list[row_i, -last_col]), collapse = "|")
      all_but_first <- paste0(unlist(ref_list[row_i, -first_col]), collapse = "|")
      inter_vec <- intersect(ref_cache[[all_but_last]], ref_cache[[all_but_first]])
      temp_list[[paste0(unlist(ref_list[row_i, ]), collapse = "|")]] <- as.integer(inter_vec)
    }
    master_item_cache[[paste0("p", c_i)]] <- temp_list
  }
  return(master_item_cache)
}
