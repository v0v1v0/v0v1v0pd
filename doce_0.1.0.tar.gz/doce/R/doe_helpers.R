make_blocks_for_part_1 <- function(versions, tasks) {
  frame <- expand.grid(1:versions, 1:tasks)
  frame <- frame[order(frame[, 1], frame[, 2]), ]

  output <- data.frame("block1" = (frame[, 1] == 1) * 1)
  if (versions > 1) {
    for (i in 2:versions) {
      output[[paste0("block", i)]] <- (frame[, 1] == i) * 1
    }
  }
  if (tasks > 1) {
    for (i in 2:tasks) {
      output[[paste0("task", i)]] <- (frame[, 2] == i) * 1
    }
  }

  mat <- as.matrix(output)[, -1]
  mode(mat) <- "integer"
  return(mat)
}

make_xmat_part1 <- function(consideration_set) {
  xmat <- matrix(0L, nrow = nrow(consideration_set), ncol = max(consideration_set))

  for (i in 1:nrow(consideration_set)) {
    xmat[i, consideration_set[i, ]] <- 1L
  }
  mode(xmat) <- "integer"
  return(xmat)
}



remove_prohibitions_from_consideration_set <- function(consideration_set, prohibitions) {
  xmat_consideration_set <- matrix(0L, nrow = nrow(consideration_set), ncol = max(consideration_set))
  for (row_i in 1:nrow(consideration_set)) {
    xmat_consideration_set[row_i, consideration_set[row_i, ]] <- 1L
  }

  keep <- rep(T, nrow(consideration_set))

  if (is.null(prohibitions) == F) {
    for (i in prohibitions) {
      my_filter <- rep(T, nrow(xmat_consideration_set))
      for (j in i) {
        my_filter <- my_filter & xmat_consideration_set[, j] == 1
      }
      keep <- keep & my_filter == F
    }
  }
  return(consideration_set[keep, ])
}


make_effects_matrix_absent <- function(candidates) {
  df <- as.data.frame(candidates)
  n <- nrow(df)
  X <- matrix(1, n, 1)
  colnames(X) <- "intercept"
  for (var in names(df)) {
    vals <- df[[var]]
    nz_levels <- sort(unique(vals[vals != 0]))
    Lnz <- length(nz_levels)
    if (Lnz <= 1) next
    C <- contr.sum(Lnz)
    for (k in seq_len(ncol(C))) {
      col_vec <- numeric(n)
      idx <- match(vals, nz_levels, nomatch = 0)
      col_vec[idx > 0] <- C[idx[idx > 0], k]
      X <- cbind(X, col_vec)
      colnames(X)[ncol(X)] <- paste0(var, "_c", k)
    }
  }
  return(X)
}






vt <- function(zi, st) {
  t(zi) %*% st %*% zi
}
ct <- function(z1v, z2v, st) {
  t(z1v) %*% st %*% z2v
}

delta_t <- function(row_i, cand_i, cand_j, st, blocks, xmat) {
  brow_i <- blocks[row_i, ]
  z_new <- c(brow_i, xmat[cand_j, ])
  z_old <- c(brow_i, xmat[cand_i, ])


  p1 <- vt(z_new, st)
  p2 <- vt(z_old, st)

  p1 - p2 + ct(z_new, z_old, st)^2 - p1 * p2
}


# rank1_update <- function(vec, S, add = TRUE) {
#   vec <- matrix(vec, ncol = 1)
#   Su <- S %*% vec
#   num <- Su %*% t(Su) #  (S u)(uᵀ S)
#   den <- as.numeric(
#     if (add) {
#       1 + t(vec) %*% S %*% vec
#     } else {
#       1 - t(vec) %*% S %*% vec
#     } # ← only one minus
#   )
#   if (add) S - num / den else S + num / den
# }


# updated_S <- function(row_i, cand_i, cand_j, st, blocks, xmat) {
#   brow_i <- blocks[row_i, ]
#   z_new <- c(brow_i, xmat[cand_j, ])
#   z_old <- c(brow_i, xmat[cand_i, ])


#   st2 <- rank1_update(z_old, st, add = FALSE) # delete
#   rank1_update(z_new, st2, add = TRUE) # add
# }

updated_S <- function(row_i, cand_i, cand_j, st, blocks, xmat, eps = 1e-12) {
  docecore:::updated_S_cpp(row_i - 1L, cand_i - 1L, cand_j - 1L, st, blocks, xmat, eps)
}


# doe_find_best_delta_R <- function(row_i, cand_i, test_cand, st, blocks, xmat) {
#   best_pair <- c()
#   best_delta <- -Inf
#   for (cand_j in test_cand) {
#     if (cand_i == cand_j) {
#       next
#     }
#     dx <- delta_t(row_i, cand_i, cand_j, st, blocks, xmat)
#     if (is.nan(dx) == F && dx > best_delta) {
#       best_delta <- dx
#       best_pair <- cand_j
#     }
#   }
#   return(list(best_pair = best_pair, best_delta = best_delta))
# }


doe_find_best_delta_R <- function(row_i, cand_i, test_cand, st, blocks, xmat) {
 delta <- docecore:::doe_find_best_delta_cpp(as.integer(row_i - 1), 
                                                  as.integer(cand_i - 1), 
                                                  as.integer(test_cand - 1), st, blocks, xmat)
 delta$best_pair<- delta$best_pair + 1 
 return(delta)
}

doe_find_best_delta <- function(row_i, cand_i, test_x, st, blocks, xmat,num_of_chunks=1) {
  if (num_of_chunks == 1) {
    delta <- doe_find_best_delta_R(
      row_i ,
      cand_i ,
      test_x , st, blocks, xmat
    )
  } else {
    test_cand_chunks <- split(
      test_x,
      rep(1:num_of_chunks, length.out = length(test_x))
    )

    # Create job list, one per chunk
    jobs <- lapply(test_cand_chunks, function(chunk) {
      list(
        chunk = chunk,
        row_i = row_i,
        cand_i = cand_i,
        st = st,
        blocks = blocks,
        xmat = xmat
      )
    })


    parallel_doe_search <- purrr::in_parallel(
      \(job) {
        with(job, {
          doce:::doe_find_best_delta_R(row_i, cand_i, chunk, st, blocks, xmat)
        })
      }
    )

    results <- purrr::map(jobs, parallel_doe_search)

    delta <- purrr::reduce(results, function(a, b) {
      if (is.null(a$best_delta) || b$best_delta > a$best_delta) b else a
    })
  }
  return(delta)
}


#' Fast log-det after a two-row swap (1-based R wrapper)
#'
#' Replaces the 4x rank-1 update block in R by calling the C++ implementation.
#' Returns the log-determinant of the updated inverse information matrix S.
#'
#' @param pi,pj Integers (1-based). The two row indices you are swapping.
#' @param st    Current inverse information matrix (S).
#' @param blocks,xmat Design matrices used to build the z vectors.
#' @param eps   Numerical safeguard passed to the C++ routine.
#'
#' @return A single numeric: \code{logdet(S2)} after the swap.
#' @export
row_swap_logdet <- function(pi, pj, st, blocks, xmat, eps = 1e-12) {
  # Extract the two rows once (C++ expects arma::rowvec)
  temp_i <- xmat[pi, , drop = FALSE]
  temp_j <- xmat[pj, , drop = FALSE]

  # Call the C++ function (expects 0-based indices)
  docecore:::row_swap_logdet_cpp(
    pi  = pi - 1L,
    pj  = pj - 1L,
    temp_i = as.numeric(temp_i),
    temp_j = as.numeric(temp_j),
    S   = st,
    blocks = blocks,
    xmat   = xmat,
    eps    = eps
  )
}