
maxdiff_design_object <- function(num_of_items = 20,
                                  n_groups = 1,
                                  n_versions_per_group = 300,
                                  tasks = 12,
                                  concepts = 5,
                                  prohibitions = NULL) {
  self <- new.env()
  self$num_of_items <- num_of_items
  self$n_groups <- n_groups
  self$n_versions_per_group <- n_versions_per_group
  total_versions <- self$n_groups * self$n_versions_per_group
  self$tasks <- tasks
  self$concepts <- concepts
  self$consideration_set <- t(combn(num_of_items, concepts)) |> as.matrix()

  if (is.null(prohibitions) == F) {
    self$consideration_set <- remove_prohibitions_from_consideration_set(self$consideration_set, prohibitions)
  }

  mode(self$consideration_set) <- "integer"

  self$xmat <- make_xmat_part1(self$consideration_set)
  self$master_item_cache <- create_master_cache(self)

  self$blocks <- make_blocks_for_part_1(n_versions_per_group, tasks)


  self$design_groups <- vector("list", n_groups)

  for (group_i in seq_len(n_groups)) {
    self$design_groups[[group_i]] <- maxdiff_create_random_design(self)
  }


  reshape <- function(n_groups) {
    all_rows <- c(unlist(self$design_groups))

    total_rows <- length(all_rows)
    rows_per_group <- total_rows / (n_groups)


    self$design_groups <- vector("list", n_groups)
    for (group_i in seq_len(n_groups)) {
      start_rows_i <- (group_i - 1) * rows_per_group + 1
      self$design_groups[[group_i]] <- as.integer(all_rows[start_rows_i:(start_rows_i + rows_per_group - 1)])
    }

    self$n_groups <- n_groups
    self$n_versions_per_group <- rows_per_group / self$tasks
    self$blocks <- make_blocks_for_part_1(self$n_versions_per_group, self$tasks)
    message("Finished")
  }


  iterate <- function(search_versions = NULL,
                      break_after = 10,
                      max_loop = 10000,
                      search_proportion = .5,
                      num_of_chunks = 1,
                      p_range = NULL,
                      max_cores = 1,
                      seed = NULL) {
    t1 <- Sys.time()
    final_seed <- sample.int(.Machine$integer.max, 1)
    set.seed(seed)

    if (max_cores > 1) {
      self$design_groups <- pmap_chunked(
        .x = as.list(seq_len(self$n_groups)),
        .f = maxdiff_d_optimal_search,
        self = self,
        search_versions = search_versions,
        break_after = break_after,
        max_loop = max_loop,
        search_proportion = search_proportion,
        num_of_chunks = num_of_chunks,
        p_range = p_range,
        save_dir = NULL,
        max_cores = max_cores,
        seed = seed
      )
    } else {
      for (group_i in seq_len(self$n_groups)) {
        self$design_groups[[group_i]] <- maxdiff_d_optimal_search(
          group_i,
          self,
          search_versions = search_versions,
          break_after = break_after,
          max_loop = max_loop,
          search_proportion = search_proportion,
          num_of_chunks = num_of_chunks,
          p_range = p_range
        )
      }
    }
    set.seed(final_seed)
    t2 <- Sys.time()
    cat("\nAll chunks completed (", round(as.numeric(difftime(t2, t1, units = "mins")), 2), " mins).\n")
  }

  get_consideration_set <- function() {
    return(self$consideration_set)
  }

  output <- function() {
    frame <- expand.grid(1:total_versions, 1:tasks)
    frame <- frame[order(frame[, 1], frame[, 2]), ]
    colnames(frame) <- c("version", "task")

    current_set <- c(unlist(self$design_groups))

    design <- cbind(frame, self$consideration_set[current_set, ])

    design <- tidyr::pivot_longer(design,
      cols = -(1:2),
      names_to = "concept"
    ) |>
      dplyr::group_by(version, task) |>
      dplyr::mutate(value = sample(value, length(value))) |>
      tidyr::pivot_wider(
        names_from = "concept",
        names_prefix = "item",
        values_from = "value"
      )
    maxdiff_sort_concepts(design)
  }



  return(list(
    reshape = reshape,
    iterate = iterate,
    get_consideration_set = get_consideration_set,
    output = output,
    self = self
  ))
}




maxdiff_create_random_design <- function(self) {
  versions <- self$n_versions_per_group
  tasks <- self$tasks
  consideration_set <- self$consideration_set
  xmat <- make_xmat_part1(consideration_set)
  current_set <- sample(1:nrow(consideration_set), versions * tasks, replace = F)

  return(current_set)
}



maxdiff_d_optimal_search <- function(group_i, self,
                                     search_versions = NULL,
                                     break_after = 10,
                                     max_loop = 10000,
                                     search_proportion = .5,
                                     num_of_chunks = 1,
                                     p_range = NULL) {
  current_set <- self$design_groups[[group_i]]
  num_of_items <- self$num_of_items
  versions <- self$n_versions_per_group
  tasks <- self$tasks
  concepts <- self$concepts
  xmat <- self$xmat
  blocks <- self$blocks
  consideration_set <- self$consideration_set

  if (is.null(search_versions)) {
    search_versions <- 1:versions
  }
  search_versions_length <- length(search_versions)

  eps <- 1e-12

  switch_zero_times <- 0
  cat(sprintf("Starting Group %2.0f", group_i))
  for (loop_i in 1:max_loop) {
    # cat(sprintf("\n[Group %2.0f] Loop %2.0f:", group_i, loop_i))
    loop_t1 <- Sys.time()

    switch_count <- 0
    xt <- cbind(blocks, xmat[current_set, ])
    mt <- t(xt) %*% xt
    st <- solve(mt)
    for (t_i in sample(1:tasks, tasks)) {
      counter <- 0
      for (v_i in search_versions[sample(1:search_versions_length, search_versions_length)]) {
        row_i <- (v_i - 1) * (tasks) + t_i
        cand_i <- current_set[row_i]

        consideration_indices <- get_consideration_indices(cand_i, self, search_proportion, p_range)

        delta <- doe_find_best_delta(row_i, cand_i, consideration_indices, st, blocks, xmat, num_of_chunks)

        if (delta$best_delta <= eps) {
          next
        }

        current_set[row_i] <- as.integer(delta$best_pair)

        st <- updated_S(row_i, cand_i, delta$best_pair, st, blocks, xmat)
        switch_count <- switch_count + 1
        counter <- counter + 1
      }
      # cat(sprintf("%3.0f ", counter))
    }
    loop_t2 <- Sys.time()
    print_time <- round(as.numeric(difftime(loop_t2, loop_t1, units = "mins")), 2)
    cat(sprintf("\nGroup\t%2.0f\tLoop\t%2.0f\tChanged\t%3.0f\tMinutes\t%3.2f", group_i, loop_i, switch_count, print_time))
    # cat(paste0("n=", switch_count))
    if (switch_count == 0) {
      switch_zero_times <- switch_zero_times + 1
    } else {
      switch_zero_times <- 0
    }
    if (switch_zero_times >= break_after) {
      break
    }
  }

  return(current_set)
}





maxdiff_sort_concepts <- function(design) {
  num_of_items <- max(c(unlist(design[, -(1:2)])))
  versions <- max(design[, 1])
  tasks <- max(design[, 2])
  concepts <- ncol(design) - 2

  colnames(design)[1:2] <- c("version", "task")
  long_design <- tidyr::pivot_longer(design,
    cols = -(1:2),
    names_to = "concept"
  ) |>
    dplyr::group_by(version, task) |>
    dplyr::mutate(value = sample(value, length(value)))


  broken_out <- make_effects_matrix_absent(long_design[, -(1:2)])[, -1]

  blocks <- broken_out[, which(grepl("^concept_", colnames(broken_out)))]
  xmat <- broken_out[, which(grepl("^concept_", colnames(broken_out)) == F)]



  xt <- cbind(blocks, xmat)
  mt <- t(xt) %*% xt
  st <- solve(mt)


  frame <- long_design[, 1:3]

  eps <- 1e-12
  loop_i <- 1
  cat("\nPositioning: ")
  for (loop_i in 1:100) {
    switch_count <- 0

    t_i <- 1
    v_i <- 1
    for (t_i in 1:tasks) {
      xt <- cbind(blocks, xmat)
      mt <- t(xt) %*% xt
      st <- solve(mt)
      old_log_det <- docecore:::logdet_cpp(st)
      for (v_i in 1:versions) {
        consideration_set <- which(frame$version == v_i & frame$task == t_i)

        for (ci in 1:(length(consideration_set) - 1)) {
          for (cj in (ci + 1):length(consideration_set)) {
            pi <- consideration_set[ci]
            pj <- consideration_set[cj]
            test_log_det <- row_swap_logdet(pi, pj, st, blocks, xmat, eps = 1e-12)

            if (test_log_det < old_log_det) {
              cat("+")
              temp_i <- xmat[pi, , drop = FALSE]
              temp_j <- xmat[pj, , drop = FALSE]
              xmat[pi, ] <- temp_j
              xmat[pj, ] <- temp_i
              xt <- cbind(blocks, xmat)
              mt <- t(xt) %*% xt
              st <- solve(mt)
              old_log_det <- docecore:::logdet_cpp(st)
              switch_count <- switch_count + 1
            }
          }
        }
      }
    }

    if (switch_count == 0) {
      break
    }
  }

  frame$item <- apply(xmat, 1, function(x) {
    if (all(x == -1)) {
      return(length(x) + 1)
    } else {
      return(which(x %in% 1))
    }
  })


  final_design <- tidyr::pivot_wider(frame,
    names_from = concept,
    names_prefix = "Item",
    values_from = "item"
  )


  return(final_design)
}
