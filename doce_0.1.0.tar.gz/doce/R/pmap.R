pmap_chunked <- function(.x, .f, ..., save_dir = NULL,
                         max_cores = parallel::detectCores() - 1,
                         seed = NULL) {
  if (!is.list(.x)) stop(".x must be a list.")
  n <- length(.x)
  if (n == 0) {
    return(list())
  }

  num_of_chunks <- n





  # figure out how many elements per chunk
  chunk_size <- ceiling(n / num_of_chunks)
  # split into that many roughly-even chunks
  chunks <- split(.x, ceiling(seq_along(.x) / chunk_size))
  n_chunks <- length(chunks)

  # Prepare workspace & subdirs
  save_dir <- pmap_prepare_workspace(save_dir)


  final_seed <- sample.int(.Machine$integer.max, 1)
  if (!is.null(seed)) {
    set.seed(seed)
    chunk_seeds <- sample.int(.Machine$integer.max, num_of_chunks)
    saveRDS(chunk_seeds, file.path(save_dir, "seeds.rds"))
  }


  dir.create(file.path(save_dir, "inputs"), showWarnings = FALSE)
  dir.create(file.path(save_dir, "outputs"), showWarnings = FALSE)
  dir.create(file.path(save_dir, "logs"), showWarnings = FALSE)

  # Write function + args
  pmap_write_function_and_args(.f, list(...), save_dir)

  # Write chunked inputs
  input_paths <- file.path(save_dir, "inputs", sprintf("input_%d.rds", seq_len(n_chunks)))
  output_paths <- file.path(save_dir, "outputs", sprintf("output_%d.rds", seq_len(n_chunks)))
  log_paths <- file.path(save_dir, "logs", sprintf("log_%d.txt", seq_len(n_chunks)))
  mapply(saveRDS, chunks, input_paths)

  # Worker script
  pmap_write_chunked_worker_script(save_dir)

  # Run & monitor
  pmap_run_chunked_processes(input_paths, output_paths, log_paths, max_cores)

  # Collect & flatten

  results <- pmap_flatten_chunks(output_paths)


  unlink(save_dir, recursive = TRUE)

  set.seed(final_seed)
  invisible(results)
}


pmap_prepare_workspace <- function(save_dir) {
  if (is.null(save_dir)) {
    save_dir <- tempfile("pmap_")
  }
  dir.create(save_dir, recursive = TRUE, showWarnings = FALSE)
  normalizePath(save_dir)
}

pmap_write_function_and_args <- function(fun, args, dir) {
  saveRDS(fun, file.path(dir, "fun.rds"))
  saveRDS(args, file.path(dir, "args.rds"))
}

pmap_write_chunked_worker_script <- function(dir) {
  script <- file.path(dir, "worker.R")
  lines <- c(
    "args       <- commandArgs(trailingOnly = TRUE)",
    "input_file <- normalizePath(args[1])",
    "output_file<- normalizePath(args[2])",
    "log_file   <- normalizePath(args[3])",
    "work_dir   <- dirname(input_file); setwd(work_dir)",
    "sink(log_file, split = TRUE)",
    "tryCatch({",
    "  fun        <- readRDS(file.path('..','fun.rds'))",
    "  extra_args <- readRDS(file.path('..','args.rds'))",
    "  inputs     <- readRDS(basename(input_file))",
    "  chunk_index <- as.integer(gsub('[^0-9]', '', basename(input_file)))",
    "  seeds <- readRDS(file.path('..', 'seeds.rds'))",
    "  set.seed(seeds[chunk_index])",
    "  results    <- vector('list', length(inputs))",
    "  for (i in seq_along(inputs)) {",
    "    results[[i]] <- tryCatch(",
    "      do.call(fun, c(list(inputs[[i]]), extra_args)),",
    "      error = function(e) list(error = conditionMessage(e))",
    "    )",
    "  }",
    "  saveRDS(results, output_file)",
    "}, error = function(e) {",
    "  cat('CHUNK ERROR:', conditionMessage(e), '\\n')",
    "})",
    "sink()"
  )
  writeLines(lines, script)
}

pmap_run_chunked_processes <- function(inputs, outputs, logs, max_cores) {
  n <- length(inputs)
  started <- rep(FALSE, n)
  seen_line_counts <- rep(0L, n) # track how many lines we've printed per chunk

  rscript_bin <- file.path(R.home("bin"), "Rscript")
  script <- file.path(dirname(inputs[[1]]), "..", "worker.R")
  progress_count <- 0
  while (sum(file.exists(outputs)) < n) {
    fex <- file.exists(outputs)
    running <- sum(started & !fex)

    while (progress_count < sum(fex)) {
      progress_count <- progress_count + 1
    }

    while (running < max_cores && any(!started & !fex)) {
      i <- which(!started & !fex)[1]
      system2(rscript_bin,
        args = c(script, inputs[i], outputs[i], logs[i]),
        wait = FALSE
      )
      started[i] <- TRUE
      running <- running + 1
      Sys.sleep(.1)
    }


    # Poll logs: print only unseen lines, excluding last
    for (i in which(started & !fex)) {
      if (file.exists(logs[i])) {
        lines <- tryCatch(readLines(logs[i], warn = FALSE), error = function(e) character())
        n_lines <- length(lines)
        if (n_lines > seen_line_counts[i]) {
          new_lines <- lines[(seen_line_counts[i] + 1):(n_lines)]
          output <- paste0(paste(new_lines, collapse = "\n"), "\n")
          output <- gsub("\n\n", "\n", output, fixed = T)
          if (output != "\n") {
            cat(output)
          }
          seen_line_counts[i] <- n_lines
        }
      }
    }


    Sys.sleep(2)
  }
}

pmap_flatten_chunks <- function(output_paths) {
  chunks <- vector("list", length(output_paths))
  pid <- util_cli_progress_bar("Reading Chunks", total = length(output_paths), type = "iterator")
  for (i in seq_len(length(output_paths))) {
    chunks[[i]] <- readRDS(output_paths[i])
    util_cli_progress_update(pid)
  }
  util_cli_progress_done(pid)
  x <- do.call(c, chunks)
  return(x)
}



util_cli_progress_message <- function(msg) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    message(msg)
  } else {
    return(cli::cli_progress_message(
      msg = msg
    ))
  }
}

util_cli_progress_bar <- function(name, total, type) {
  e <- new.env()
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    message(paste0(name, " - ", total, " ", type))
    e$cat_int <- floor(total / 10)
    e$count <- 0
  } else {
    cli::cli_progress_bar(
      name = name,
      total = total,
      type = type,
      .envir = e
    )
  }
  return(e)
}

util_cli_progress_update <- function(id) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    id$count <- id$count + 1
    if ((id$count %% id$cat_int) == 0) {
      cat(".")
    }
  } else {
    return(cli::cli_progress_update(.envir = id))
  }
}

util_cli_progress_done <- function(id) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    cat(".\n")
  } else {
    return(cli::cli_progress_done(.envir = id))
  }
  rm(id)
}


util_cli_rule <- function(left) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    message(paste0(left, "---------------------"))
  } else {
    return(cli::cli_rule(left = left))
  }
}

util_cli_text <- function(..., .envir = parent.frame()) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    message(paste0(...))
  } else {
    return(cli::cli_text(..., .envir = .envir))
  }
}
util_cli_alert_info <- function(text,
                                id = NULL,
                                class = NULL,
                                wrap = FALSE,
                                .envir = parent.frame()) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    message(text)
  } else {
    return(cli::cli_alert_info(text,
      id = id,
      class = class,
      wrap = wrap,
      .envir = .envir
    ))
  }
}
util_style_bold <- function(...) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    return(paste0(...))
  } else {
    return(cli::style_bold(...))
  }
}

util_style_italic <- function(...) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    return(paste0(...))
  } else {
    return(cli::style_italic(...))
  }
}
util_col_blue <- function(...) {
  numerious_tools <- getOption("numerious_tools", default = F)
  if (numerious_tools) {
    return(paste0(...))
  } else {
    return(cli::col_blue(...))
  }
}
